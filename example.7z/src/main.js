import './assets/css/main.css'

import 'element-plus/dist/index.css';
import 'leaflet/dist/leaflet.css';
import '@supermap/iclient-leaflet/dist/iclient-leaflet.css';
import "@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css"

import { createApp } from 'vue'
import App from './App.vue'

const app = createApp(App)


app.mount('#app')
