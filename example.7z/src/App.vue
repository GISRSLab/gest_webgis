<script setup>
import HomeMap from '@/components/HomeMap.vue';
import BufferMap from '@/components/BufferMap.vue';
import SuperMap from '@/components/SuperMap.vue';
import ShortestMap from '@/components/ShortestPath.vue';
import TestComp from '@/components/TestComp.vue';
</script>

<template>
  <div class="w-full h-full flex flex-row items-center justify-center">
    <div class="grid grid-cols-2 grid-rows-2 gap-5 bg-slate-100 w-2/3 h-full">
      <div class="w-full flex flex-col items-center justify-center">
        <h1 class="font-bold">加载天地图</h1>
        <HomeMap />
      </div>
      <div class="w-full flex flex-col items-center justify-center">
        <h1 class="font-bold">加载iServer瓦片地图</h1>
        <SuperMap />
      </div>
      <div class="w-full relative">
        <h1 class="flex items-center justify-center font-bold">
          缓冲区
        </h1>
        <BufferMap />
      </div>
      <div class="w-full relative">
        <h1 class="flex items-center justify-center font-bold">最短路径</h1>
        <ShortestMap />
      </div>
    </div>
    <div class="flex flex-col w-1/2 items-center justify-center gap-10">
      <h1 class="font-bold">测试 Tailwindcss & Element-plus</h1>
      <TestComp />
    </div>
  </div>
</template>

<style scoped>

</style>
