<script setup >
import {ElButton} from 'element-plus';
</script>

<template>
<div class="flex items-center justify-center w-full">
<div class="shadow-lg bg-blue-100 rounded-3xl w-40 h-40 flex gap-3 flex-col items-center justify-center">
  <el-button type="primary">Element-plus</el-button>
  <div class="text-purple-600 font-bold">Tailwind CSS</div>
</div>
</div>
</template>

<style scoped>

</style>